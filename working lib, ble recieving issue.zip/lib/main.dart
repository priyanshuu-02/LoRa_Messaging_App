import 'package:flutter/material.dart';
import 'package:lora_communicator/providers/chat_provider.dart';
import 'package:lora_communicator/screens/chat_screen.dart';
import 'package:lora_communicator/services/ble_service.dart';
import 'package:lora_communicator/services/packet_framer_service.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const LoRaCommunicatorApp());
}

class LoRaCommunicatorApp extends StatelessWidget {
  const LoRaCommunicatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Use MultiProvider to make your services available to the entire app.
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<BleService>(create: (_) => BleService()),
        ChangeNotifierProvider<PacketFramerService>(
          create: (context) => PacketFramerService(
            bleService: context.read<BleService>(),
          ),
        ),
        ChangeNotifierProvider<ChatProvider>(
          create: (context) => ChatProvider(
            framerService: context.read<PacketFramerService>(),
          ),
        ),
      ],
      child: MaterialApp(
        title: 'LoRa Communicator',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: Colors.black,
          colorScheme: ColorScheme.fromSeed(
              seedColor: Colors.blue, brightness: Brightness.dark),
        ),
        home: const ChatScreen(),
      ),
    );
  }
}
